ui_print "- Thermal & Fast Charge Control (MT6789)"
mkdir -p /data/adb/thermalfast
[ -f /data/adb/thermalfast/config ] || printf 'THERMAL_DISABLE=0\nFAST_CHARGE=0\nFC_CURRENT=3000000\nCUTOFF=48\n' > /data/adb/thermalfast/config
set_perm_recursive $MODPATH 0 0 0755 0755
if [ -f $MODPATH/app/ThermalFast.apk ]; then
  cp $MODPATH/app/ThermalFast.apk /data/local/tmp/tf.apk
  pm install -r /data/local/tmp/tf.apk >/dev/null 2>&1 && ui_print "- App terpasang" || ui_print "- App dipasang saat boot"
  rm -f /data/local/tmp/tf.apk
fi
