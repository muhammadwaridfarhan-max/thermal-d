#!/system/bin/sh
# Logika disable thermal diambil dari service.sh Hiperion Thermal (@MiAzami), dibuat reversibel.
D=${TF_DIR:-/data/adb/thermalfast}; ORIG=$D/orig; CFG=$D/config
BATT=${TF_BATT:-/sys/class/power_supply/battery/temp}
mkdir -p $ORIG
THERMAL_DISABLE=0; FAST_CHARGE=0; FC_CURRENT=3000000; CUTOFF=48
[ -f $CFG ] && . $CFG
[ "$FC_CURRENT" -gt 4000000 ] && FC_CURRENT=4000000
[ "$FC_CURRENT" -lt 1000000 ] && FC_CURRENT=1000000

# ---------- pengaman suhu (satuan sysfs: 0.1 C) ----------
bt=$(cat $BATT 2>/dev/null); case "$bt" in ''|*[!0-9]*) bt=0;; esac
TRIP=0
if [ "$THERMAL_DISABLE" = 1 ]; then
  if [ "$bt" -ge $((CUTOFF*10)) ]; then TRIP=1; touch $D/tripped
  elif [ -f $D/tripped ] && [ "$bt" -ge $((CUTOFF*10-50)) ]; then TRIP=1
  else rm -f $D/tripped; fi
else rm -f $D/tripped; fi
EFF=$THERMAL_DISABLE; [ "$TRIP" = 1 ] && EFF=0

# ---------- THERMAL ----------
GP=/proc/gpufreq/gpufreq_power_limited
OC=/proc/mtk_batoc_throttling/battery_oc_protect_stop
CL=/sys/devices/virtual/thermal/thermal_message/cpu_limits
PS=/proc/ppm/policy_status

list_svcs() {
  find /system/etc/init /vendor/etc/init /odm/etc/init -type f 2>/dev/null | xargs grep -h "^service" 2>/dev/null \
    | awk '{print $2}' | grep thermal | grep -viE 'hal|hardware|symlinks' | sort -u
}

if [ "$EFF" = 1 ]; then
  touch $D/active
  for z in /sys/class/thermal/thermal_zone*/mode; do [ -w "$z" ] && echo disabled > "$z"; done
  for s in $(list_svcs); do
    if [ "$(getprop init.svc.$s)" = running ]; then stop $s; touch $D/stopped.$s; fi
    if [ -f $D/stopped.$s ]; then pid=$(pidof $s); [ -n "$pid" ] && kill -9 $pid; fi
  done
  if [ -w $GP ]; then
    for k in ignore_batt_oc ignore_batt_percent ignore_low_batt ignore_thermal_protect ignore_pbm_limited; do echo "$k 1" > $GP; done
  fi
  if [ -f $PS ]; then
    for i in $(grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' $PS | awk -F'[][]' '{print $2}'); do echo "$i 0" > $PS; done
  fi
  if [ -w $CL ]; then
    for c in /sys/devices/system/cpu/cpu[0-9]*; do
      m=$(cat $c/cpufreq/cpuinfo_max_freq 2>/dev/null); [ -n "$m" ] && echo "${c##*/} $m" > $CL
    done
  fi
  [ -w $OC ] && echo "stop 1" > $OC
  [ -f $D/override ] || { cmd thermalservice override-status 0 >/dev/null 2>&1; touch $D/override; }
elif [ -f $D/active ]; then
  for z in /sys/class/thermal/thermal_zone*/mode; do [ -w "$z" ] && echo enabled > "$z"; done
  for f in $D/stopped.*; do [ -e "$f" ] || continue; start "${f##*/stopped.}"; rm -f "$f"; done
  if [ -w $GP ]; then
    for k in ignore_batt_oc ignore_batt_percent ignore_low_batt ignore_thermal_protect ignore_pbm_limited; do echo "$k 0" > $GP; done
  fi
  if [ -f $PS ]; then
    for i in $(grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' $PS | awk -F'[][]' '{print $2}'); do echo "$i 1" > $PS; done
  fi
  [ -w $OC ] && echo "stop 0" > $OC
  cmd thermalservice reset >/dev/null 2>&1; rm -f $D/override $D/active
fi

# ---------- FAST CHARGE (MT6789: GM3.0 charger kernel, tidak ada node "force current" resmi) ----------
key() { echo "$ORIG/$(echo "$1" | tr '/' '_')"; }
FC_NODES="/sys/class/power_supply/battery/constant_charge_current_max
/sys/class/power_supply/battery/input_current_limit
/sys/class/power_supply/mtk-master-charger/input_current_limit
/sys/class/power_supply/usb/input_current_limit
/sys/class/power_supply/main/constant_charge_current_max"
fcn=0
if [ "$FAST_CHARGE" = 1 ]; then
  for n in $FC_NODES; do
    [ -w "$n" ] || continue
    fcn=$((fcn+1)); cur=$(cat "$n" 2>/dev/null)
    [ -f "$(key $n)" ] || echo "$cur" > "$(key $n)"
    case "$cur" in ''|*[!0-9]*) continue;; esac
    [ "$cur" -lt "$FC_CURRENT" ] && echo "$FC_CURRENT" > "$n"   # hanya menaikkan, tidak pernah menurunkan
  done
  for c in /sys/class/thermal/cooling_device*; do   # pembatas arus dari thermal (bcct/adp/charger)
    case "$(cat $c/type 2>/dev/null)" in *bcct*|*adp*|*[Cc]harg*)
      [ -w $c/cur_state ] && { echo 0 > $c/cur_state; fcn=$((fcn+1)); };;
    esac
  done
else
  for n in $FC_NODES; do
    [ -w "$n" ] && [ -f "$(key $n)" ] && { cat "$(key $n)" > "$n"; rm -f "$(key $n)"; }
  done
fi

zones=$(ls -d /sys/class/thermal/thermal_zone*/mode 2>/dev/null | wc -l)
stopped=$(ls $D/stopped.* 2>/dev/null | wc -l)
printf 'TRIPPED=%s\nSTOPPED=%s\nFCNODES=%s\nZONES=%s\n' "$TRIP" "$stopped" "$fcn" "$zones" > $D/state
