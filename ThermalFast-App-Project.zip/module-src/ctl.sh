#!/system/bin/sh
D=/data/adb/thermalfast; CFG=$D/config
case "$1" in
  get) cat $CFG $D/state 2>/dev/null ;;
  set)
    case "$3" in ""|*[!0-9]*) exit 1;; esac
    case "$2" in
      THERMAL_DISABLE|FAST_CHARGE) [ "$3" -le 1 ] || exit 1;;
      FC_CURRENT) [ "$3" -ge 1000000 ] && [ "$3" -le 4000000 ] || exit 1;;
      CUTOFF) [ "$3" -ge 40 ] && [ "$3" -le 55 ] || exit 1;;
      *) exit 1;;
    esac
    grep -v "^$2=" $CFG > $CFG.tmp 2>/dev/null; echo "$2=$3" >> $CFG.tmp; mv $CFG.tmp $CFG
    sh ${0%/*}/apply.sh ;;
esac
