#!/system/bin/sh
# Props dari Hiperion Thermal; hanya berlaku sejak boot, jadi dipasang kalau toggle thermal aktif.
D=/data/adb/thermalfast
[ -f $D/config ] && . $D/config
[ "$THERMAL_DISABLE" = 1 ] || exit 0
command -v resetprop >/dev/null 2>&1 || exit 0
resetprop -n ro.vendor.mtk_thermal_2_0 0
resetprop -n persist.thermal_config.mitigation 0
resetprop -n ro.mtk_thermal_monitor.enabled false
