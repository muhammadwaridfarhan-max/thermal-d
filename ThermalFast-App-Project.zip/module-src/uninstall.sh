pm uninstall com.thermalfast.ctl >/dev/null 2>&1
rm -rf /data/adb/thermalfast
