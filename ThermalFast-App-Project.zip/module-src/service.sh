#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 10
if ! pm path com.thermalfast.ctl >/dev/null 2>&1 && [ -f $MODDIR/app/ThermalFast.apk ]; then
  cp $MODDIR/app/ThermalFast.apk /data/local/tmp/tf.apk
  pm install -r /data/local/tmp/tf.apk
  rm -f /data/local/tmp/tf.apk
fi
# diterapkan berkala: thermal HAL/charger sering mengembalikan nilai, dan ini juga dipakai pengaman suhu
while true; do sh $MODDIR/apply.sh; sleep 15; done
