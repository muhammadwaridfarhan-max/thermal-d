Module Magisk/KernelSU "Thermal & Fast Charge Control (MT6789)".
Build APK: buka di Android Studio, atau push ke GitHub (Actions menghasilkan ThermalFast-Module.zip lengkap dengan APK).
Manual: taruh APK di module/app/ThermalFast.apk, zip ISI folder module (module.prop harus di root zip), flash lewat Magisk/KernelSU.
Debug: cat /data/adb/thermalfast/state
