package com.thermalfast.ctl

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Root {
    private const val CTL = "/data/adb/modules/thermalfast/ctl.sh"

    private suspend fun run(cmd: String): String = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(); out
        } catch (e: Exception) { "" }
    }

    suspend fun available() = run("id").contains("uid=0")
    suspend fun set(key: String, value: String) = run("sh $CTL set $key $value")
    suspend fun read(): Map<String, String> = run("sh $CTL get").lines()
        .mapNotNull { l -> l.indexOf('=').takeIf { it > 0 }?.let { l.substring(0, it) to l.substring(it + 1).trim() } }
        .toMap()
}
