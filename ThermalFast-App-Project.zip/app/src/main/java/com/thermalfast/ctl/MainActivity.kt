@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.thermalfast.ctl

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    MaterialExpressiveTheme(
        colorScheme = scheme,
        motionScheme = MotionScheme.expressive(),
        shapes = Shapes(large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(40.dp))
    ) { Home() }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var root by remember { mutableStateOf<Boolean?>(null) }
    var info by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var thermal by remember { mutableStateOf(false) }
    var fast by remember { mutableStateOf(false) }
    var fcMa by remember { mutableFloatStateOf(3000f) }
    var cutoff by remember { mutableFloatStateOf(48f) }
    var busy by remember { mutableStateOf(false) }
    var temp by remember { mutableFloatStateOf(0f) }
    var nowMa by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        root = Root.available()
        if (root == true) {
            val c = Root.read(); info = c
            thermal = c["THERMAL_DISABLE"] == "1"
            fast = c["FAST_CHARGE"] == "1"
            fcMa = (c["FC_CURRENT"]?.toFloatOrNull() ?: 3000000f) / 1000f
            cutoff = c["CUTOFF"]?.toFloatOrNull() ?: 48f
        }
    }
    LaunchedEffect(Unit) {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val raw = abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
            nowMa = if (raw > 20000) raw / 1000 else raw
            if (root == true) info = Root.read()
            delay(3000)
        }
    }

    fun apply(key: String, v: String) = scope.launch {
        busy = true; Root.set(key, v); info = Root.read(); busy = false
    }
    val enabled = root == true && !busy
    val tripped = info["TRIPPED"] == "1"
    val sb = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(sb.nestedScrollConnection),
        topBar = {
            LargeFlexibleTopAppBar(
                title = { Text("Thermal & Pengisian") },
                subtitle = { Text("Helio G99 · Magisk / KernelSU") },
                scrollBehavior = sb
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Box(Modifier.fillMaxWidth().padding(24.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        Stat("%.1f°C".format(temp), "Suhu baterai")
                        Stat("$nowMa mA", "Arus pengisian")
                    }
                    if (busy) LoadingIndicator(Modifier.size(40.dp).align(Alignment.TopEnd))
                }
            }

            if (root == false) Notice("Akses root ditolak / module belum aktif. Beri izin di Magisk atau KernelSU lalu buka ulang app.", true)
            if (tripped) Notice("Pengaman suhu aktif: thermal dinyalakan lagi sementara karena baterai melewati batas.", true)

            ToggleCard(Icons.Rounded.Thermostat, "Disable thermal",
                "Zona, service & limiter MTK dimatikan", thermal, enabled) {
                thermal = it; apply("THERMAL_DISABLE", if (it) "1" else "0")
            }
            if (thermal) {
                Card(
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(Modifier.padding(24.dp)) {
                        Text("Pengaman suhu: ${cutoff.toInt()}°C", style = MaterialTheme.typography.titleMedium)
                        Text("Di atas ini thermal otomatis menyala lagi.", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = cutoff, onValueChange = { cutoff = it },
                            onValueChangeFinished = { apply("CUTOFF", cutoff.toInt().toString()) },
                            valueRange = 40f..55f, steps = 14, enabled = enabled
                        )
                    }
                }
            }

            ToggleCard(Icons.Rounded.BatteryChargingFull, "Fast charging",
                "Lepas pembatas arus & naikkan batas", fast, enabled) {
                fast = it; apply("FAST_CHARGE", if (it) "1" else "0")
            }
            if (fast) {
                Card(
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(Modifier.padding(24.dp)) {
                        Text("Batas arus: ${fcMa.toInt()} mA", style = MaterialTheme.typography.titleMedium)
                        Text("Hanya menaikkan, tidak pernah menurunkan nilai bawaan.", style = MaterialTheme.typography.bodyMedium)
                        Slider(
                            value = fcMa, onValueChange = { fcMa = it },
                            onValueChangeFinished = { apply("FC_CURRENT", (fcMa.toInt() * 1000).toString()) },
                            valueRange = 2000f..4000f, steps = 3, enabled = enabled
                        )
                    }
                }
                if (info["FCNODES"] == "0")
                    Notice("Tidak ada node arus yang bisa ditulis di kernel ini. Kecepatan pengisian tetap ditentukan charger kernel & adaptor; efek utama datang dari Disable thermal.", false)
            }

            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
            ) {
                Text(
                    "Zona thermal: ${info["ZONES"] ?: "-"}  ·  Service dihentikan: ${info["STOPPED"] ?: "-"}  ·  Node pengisian: ${info["FCNODES"] ?: "-"}",
                    Modifier.padding(20.dp), style = MaterialTheme.typography.labelLarge
                )
            }
            Notice("Mematikan thermal berisiko membuat perangkat terlalu panas dan merusak baterai/SoC. Pantau suhu di atas.", false)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun Notice(text: String, error: Boolean) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Rounded.Warning, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(12.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun Stat(value: String, label: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(value, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
    Text(label, style = MaterialTheme.typography.labelLarge)
}

@Composable
fun ToggleCard(icon: ImageVector, title: String, sub: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    val bg by animateColorAsState(
        if (checked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        label = "bg"
    )
    Card(
        onClick = { if (enabled) onChange(!checked) },
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Row(Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(32.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                Text(sub, style = MaterialTheme.typography.bodyMedium)
            }
            Switch(
                checked = checked, onCheckedChange = onChange, enabled = enabled,
                thumbContent = { if (checked) Icon(Icons.Rounded.Check, null, Modifier.size(SwitchDefaults.IconSize)) }
            )
        }
    }
}
